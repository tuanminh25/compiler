void main()
{
  ((1+2)=(i=x[1]));
}
