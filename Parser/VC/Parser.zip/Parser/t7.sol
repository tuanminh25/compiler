void main()
{
  int i;
}
