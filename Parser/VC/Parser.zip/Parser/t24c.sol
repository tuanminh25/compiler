void main()
{
  putStringLn("test");
}
