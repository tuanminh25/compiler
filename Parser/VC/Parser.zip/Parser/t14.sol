void main()
{
  f();
}
